plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.h3lium.questionextractor"; compileSdk = 35
    defaultConfig { applicationId = "com.h3lium.questionextractor"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "2.0.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.android.gms:play-services-tasks:18.2.0")
}
