package com.h3lium.questionextractor

import android.content.ContentValues
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.*
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * QuestionWise ULTRA PRO
 *
 * Important design rule:
 * TOTAL OUTPUT = TOTAL QUESTIONS DETECTED IN THE PDF.
 * There is intentionally NO hard-coded 180-question limit.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var action: Button
    private var selectedUri: Uri? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        selectedUri = uri
        action.text = "START ULTRA PRO EXTRACTION"
        status.text = "PDF selected. Automatic question-count detection is enabled."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 30)
        }
        val title = TextView(this).apply {
            text = "QuestionWise ULTRA PRO"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "PDF → automatic question detection → PNGs + ZIP\n" +
                    "90 → 90 PNGs • 180 → 180 PNGs • 200 → 200 PNGs\n" +
                    "Scanned PDFs • 1/2 columns • diagrams • tables • equations • multi-page questions"
            textSize = 14f
            setPadding(0, 10, 0, 22)
        }
        action = Button(this).apply { text = "SELECT QUESTION PAPER PDF" }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        status = TextView(this).apply {
            text = "Select a question-paper PDF to begin."
            textSize = 15f
            setPadding(0, 18, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(action)
        root.addView(progress)
        root.addView(status)
        setContentView(root)

        action.setOnClickListener {
            if (selectedUri == null) picker.launch(arrayOf("application/pdf")) else startExtraction()
        }
    }

    private data class Anchor(val number: Int, val x: Int, val y: Int, val right: Int, val bottom: Int)
    private data class Column(val left: Int, val right: Int)

    private fun startExtraction() {
        val uri = selectedUri ?: return
        action.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        status.text = "Analysing pages… please keep the app open."

        Thread {
            var renderer: PdfRenderer? = null
            var pfd: ParcelFileDescriptor? = null
            val work = File(cacheDir, "questionwise_ultra_${System.currentTimeMillis()}")
            val questionFiles = ArrayList<File>()
            try {
                work.mkdirs()
                pfd = contentResolver.openFileDescriptor(uri, "r") ?: error("Cannot open PDF")
                renderer = PdfRenderer(pfd)
                val totalPages = renderer!!.pageCount
                var expected = 1
                var active: File? = null
                var detectedCount = 0

                for (pageIndex in 0 until totalPages) {
                    val page = renderer!!.openPage(pageIndex)
                    val targetW = 1800
                    val scale = targetW.toFloat() / page.width.toFloat()
                    val targetH = max(1, (page.height * scale).toInt())
                    val pageBmp = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888)
                    pageBmp.eraseColor(Color.WHITE)
                    val matrix = Matrix().apply { setScale(scale, scale) }
                    page.render(pageBmp, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    val anchors = detectAnchors(pageBmp, expected)
                    val columns = detectColumns(anchors, pageBmp.width)
                    val ordered = orderAnchors(anchors, columns)

                    runOnUiThread {
                        progress.progress = ((pageIndex.toFloat() / max(1, totalPages)) * 75f).toInt()
                        status.text = "Page ${pageIndex + 1}/$totalPages • detected ${ordered.size} question starts • total so far $detectedCount"
                    }

                    if (ordered.isEmpty()) {
                        if (active != null) appendBitmapToFile(active!!, pageBmp, 0, 0, pageBmp.width, pageBmp.height)
                        pageBmp.recycle()
                        continue
                    }

                    // If the current question continues onto this page, preserve everything
                    // before the first new question in its column. This avoids losing options,
                    // diagrams, or explanations that cross a page boundary.
                    val first = ordered.first()
                    if (active != null && first.y > 0) {
                        appendBitmapToFile(active!!, pageBmp, 0, 0, pageBmp.width, max(1, first.y))
                        questionFiles.add(active!!)
                        active = null
                    }

                    for (i in ordered.indices) {
                        val a = ordered[i]
                        val next = ordered.getOrNull(i + 1)
                        val col = columns.firstOrNull { a.x >= it.left && a.x < it.right } ?: Column(0, pageBmp.width)
                        val left = max(0, col.left - 28)
                        val right = min(pageBmp.width, col.right + 28)
                        val top = max(0, a.y - 26)
                        val bottom = when {
                            next != null && next.x >= col.left && next.x < col.right -> max(top + 1, next.y - 20)
                            else -> min(pageBmp.height, col.right.coerceAtMost(pageBmp.height))
                        }
                        val h = max(1, bottom - top)

                        // Sequence-aware filtering prevents page headers/footers containing a
                        // random number from becoming a fake question. The detected sequence can
                        // start at 1, or continue from the previous page.
                        if (a.number == expected) {
                            if (active != null) {
                                questionFiles.add(active!!)
                                active = null
                            }
                            active = newQuestionFile(work, detectedCount + 1)
                            writeBitmap(active!!, crop(pageBmp, left, top, right - left, h), append = false)
                            detectedCount++
                            expected++
                        } else if (a.number > expected && a.number <= expected + 3) {
                            // Small OCR skips are tolerated. The file numbering is based on the
                            // actual detected question sequence, not on a hard-coded 180.
                            if (active != null) questionFiles.add(active!!)
                            active = newQuestionFile(work, detectedCount + 1)
                            writeBitmap(active!!, crop(pageBmp, left, top, right - left, h), append = false)
                            detectedCount++
                            expected = a.number + 1
                        }
                    }
                    pageBmp.recycle()
                }

                if (active != null) questionFiles.add(active!!)
                renderer?.close(); renderer = null
                pfd?.close(); pfd = null

                if (questionFiles.isEmpty()) error("No question starts were detected. Try a clearer scan or PDF.")

                // Final output is sequential 1.png, 2.png, ... N.png where N is the number
                // actually detected. Never truncate to 90/180 or pad to a fixed count.
                val finalDir = File(getExternalFilesDir(null), "QuestionWise_ULTRA")
                if (finalDir.exists()) finalDir.deleteRecursively()
                finalDir.mkdirs()
                val finalFiles = ArrayList<File>()

                questionFiles.forEachIndexed { index, src ->
                    val dst = File(finalDir, "${index + 1}.png")
                    src.copyTo(dst, overwrite = true)
                    finalFiles.add(dst)
                    runOnUiThread {
                        progress.progress = 75 + ((index + 1) * 20 / max(1, finalFiles.size.coerceAtLeast(questionFiles.size)))
                        status.text = "Saving ${index + 1}/${questionFiles.size}.png"
                    }
                }

                val zip = File(getExternalFilesDir(null), "QuestionWise_ULTRA_${questionFiles.size}_Questions.zip")
                ZipOutputStream(BufferedOutputStream(FileOutputStream(zip))).use { zos ->
                    finalFiles.forEach { file ->
                        zos.putNextEntry(ZipEntry(file.name))
                        file.inputStream().use { it.copyTo(zos) }
                        zos.closeEntry()
                    }
                }

                finalFiles.forEach { publishToDownloads(it, it.name, "image/png") }
                publishToDownloads(zip, zip.name, "application/zip")

                runOnUiThread {
                    progress.progress = 100
                    status.text = "DONE ✓\nDetected ${finalFiles.size} questions.\n${finalFiles.size} PNGs + ZIP saved in Downloads/QuestionWise_ULTRA"
                    action.isEnabled = true
                    action.text = "SELECT ANOTHER PDF"
                    selectedUri = null
                }
                work.deleteRecursively()
            } catch (e: Exception) {
                try { renderer?.close() } catch (_: Exception) {}
                try { pfd?.close() } catch (_: Exception) {}
                runOnUiThread {
                    status.text = "Extraction stopped: ${e.message ?: "Unknown error"}\nNo fixed question count is assumed."
                    action.isEnabled = true
                    action.text = "SELECT PDF / TRY AGAIN"
                }
            }
        }.start()
    }

    private fun detectAnchors(bitmap: Bitmap, expected: Int): List<Anchor> {
        val result = try {
            Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)))
        } catch (_: Exception) {
            return emptyList()
        }
        val candidates = ArrayList<Anchor>()
        for (block in result.textBlocks) for (line in block.lines) {
            val text = line.text.trim()
            val match = Regex("^(?:Q(?:uestion)?\\s*)?(\\d{1,3})\\s*[.)]\\s*").find(text)
                ?: Regex("^\\(?([0-9]{1,3})\\)?\\s+").find(text)
                ?: continue
            val number = match.groupValues[1].toIntOrNull() ?: continue
            if (number < 1 || number > 999) continue
            val box = line.boundingBox ?: continue
            // Strong sequence gate: prevents common page numbers/years from becoming anchors.
            if (number < expected - 1 || number > expected + 5) continue
            candidates.add(Anchor(number, box.left, box.top, box.right, box.bottom))
        }
        return candidates
            .sortedBy { it.y }
            .distinctBy { "${it.number}:${it.x / 30}:${it.y / 20}" }
    }

    private fun detectColumns(anchors: List<Anchor>, width: Int): List<Column> {
        if (anchors.size < 3) return listOf(Column(0, width))
        val xs = anchors.map { it.x }.sorted()
        var bestGap = 0
        var bestAt = -1
        for (i in 0 until xs.lastIndex) {
            val gap = xs[i + 1] - xs[i]
            if (gap > bestGap) { bestGap = gap; bestAt = i }
        }
        if (bestAt >= 0 && bestGap > width * 0.22) {
            val split = (xs[bestAt] + xs[bestAt + 1]) / 2
            return listOf(Column(0, split), Column(split, width))
        }
        return listOf(Column(0, width))
    }

    private fun orderAnchors(anchors: List<Anchor>, columns: List<Column>): List<Anchor> {
        if (columns.size == 1) return anchors.sortedWith(compareBy<Anchor> { it.y }.thenBy { it.x })
        return anchors.sortedWith(compareBy<Anchor> {
            columns.indexOfFirst { c -> it.x >= c.left && it.x < c.right }.let { idx -> if (idx < 0) 0 else idx }
        }.thenBy { it.y }.thenBy { it.x })
    }

    private fun newQuestionFile(work: File, n: Int): File = File(work, "q_${n}_${System.nanoTime()}.png")

    private fun writeBitmap(file: File, bitmap: Bitmap, append: Boolean) {
        if (!append) {
            FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bitmap.recycle()
            return
        }
        appendBitmapToFile(file, bitmap, 0, 0, bitmap.width, bitmap.height)
        bitmap.recycle()
    }

    private fun appendBitmapToFile(file: File, src: Bitmap, left: Int, top: Int, width: Int, height: Int) {
        val part = crop(src, left, top, width, height)
        val old = if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
        val gap = 24
        val out = if (old == null) {
            part
        } else {
            val w = max(old.width, part.width)
            val h = old.height + gap + part.height
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { canvasBmp ->
                val c = Canvas(canvasBmp)
                c.drawColor(Color.WHITE)
                c.drawBitmap(old, 0f, 0f, null)
                c.drawBitmap(part, 0f, (old.height + gap).toFloat(), null)
                old.recycle(); part.recycle()
            }
        }
        FileOutputStream(file).use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        out.recycle()
    }

    private fun crop(src: Bitmap, left: Int, top: Int, width: Int, height: Int): Bitmap {
        val l = left.coerceIn(0, max(0, src.width - 1))
        val t = top.coerceIn(0, max(0, src.height - 1))
        val w = width.coerceIn(1, src.width - l)
        val h = height.coerceIn(1, src.height - t)
        return Bitmap.createBitmap(src, l, t, w, h)
    }

    private fun publishToDownloads(file: File, name: String, mime: String) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/QuestionWise_ULTRA")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
        } catch (_: Exception) {
            contentResolver.delete(uri, null, null)
        }
    }
}
