# QuestionWise ULTRA PRO — Android

Local Android extractor for question-paper PDFs.

## Core rule
**The app does NOT assume 180 questions.** It detects question starts from the PDF and creates exactly the detected sequence as:

- 90 questions → `1.png` … `90.png`
- 180 questions → `1.png` … `180.png`
- 200 questions → `1.png` … `200.png`

The ZIP is named with the detected count, e.g. `QuestionWise_ULTRA_180_Questions.zip`.

## Processing
- Native Android `PdfRenderer`
- On-device Google ML Kit text recognition
- Automatic question-number detection
- Basic 1-column / 2-column ordering
- Safety margins around question crops
- Multi-page continuation support
- PNG export at high render width
- ZIP creation
- Saves results to `Downloads/QuestionWise_ULTRA`

## Important accuracy note
No OCR/layout system can honestly guarantee 100% accuracy on every possible scan. This build is designed to preserve options/diagrams and avoid fixed-count truncation, but unusual layouts, very poor scans, decorative numbering, or complex cross-column questions may require a review mode in a future release.

## Build
The repository includes `.github/workflows/build-apk.yml`. Run the workflow on GitHub to build `app-debug.apk` without needing Android Studio on the user's phone.
